 function myFunction(){  
	//Clear the day__person div
	$('.day__people').find('.day__person').remove();
	var employees=[];
	var sortEmployees=[];
	
	
	var MonCount=0,TueCount=0,WedCount=0,ThuCount=0,FriCount=0,SatCount=0,SunCount=0;
	var CurrentYear=document.getElementById("js-year").value;
	
	// JSON loop
	for ( var i = 0; i < 50; i++) {   
		var x=document.getElementById("json-input").value;
		var y = eval(x);
		
		// Get Year value
		var YearVal = y[i].birthday;
		YearVal = YearVal.split('/');
		var Age = CurrentYear - YearVal[2] ;
		//alert(Age)
		// Get Day on text format
		var DateOfBirth = '"'+y[i].birthday+'"';
		var DateWise = new Date(DateOfBirth);	
		DateWise = DateWise.toDateString().split(' ').slice(',');
		
		// Split the name first letter
		var NameSplit = y[i].name;
		var fullName = NameSplit;
		NameSplit = NameSplit.split(' ').slice(',');
		var FirstLetter  =  NameSplit[0];
		var SecondLetter =  NameSplit[1];
		var SplitName =FirstLetter[0]+''+SecondLetter[0];	
		
		// Day condition checked
		if(DateWise[0] == 'Mon'){  // Monday date of birth
			
				MonCount = MonCount+1;		
				var Montxt='',IDMon=$('#mon');
				IDMon.removeClass('day--empty');
				
				// sorting function			
				//employees[MonCount]={name:SplitName, age:Age}			
							
				// sortEmployees[MonCount] = '<div class="day__person" data-year="'+YearVal[2]+'"  data-age="'+employees[MonCount].age+'" data-name="'+employees[MonCount].name+'">'+employees[MonCount].name+'</div>' ;	
				
				if (Age > 0){
					Montxt = '<div class="day__person" class="day__person" data-year="'+YearVal[2]+'"  data-age="'+Age+'" data-name="'+fullName+'">'+SplitName+'</div>'
				} 
				Montxt = " "+ Montxt;
				IDMon.find('.day__people').append(Montxt);			
				
				// Width and Height Assign
				WidthHeightAssign(MonCount);
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				
		}else if(DateWise[0] == 'Tue'){ // Tuesday date of birth
			
				TueCount = TueCount+1;		
				var Tuetxt='',IDMon=$('#tue');
				if (Age > 0){				
					Tuetxt = '<div class="day__person" data-year="'+YearVal[2]+'" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Tuetxt = " "+ Tuetxt;
				IDMon.find('.day__people').append(Tuetxt);
				
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(TueCount);
							
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);	
					
		
		}else if(DateWise[0] == 'Wed'){	// Wednesday date of birth	
			if (Age > 0){ var condition = 'success';}			
			if(condition == 'success'){
				WedCount = WedCount+1;		
				var Wedtxt='',IDMon=$('#wed');	
				Wedtxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				Wedtxt = " "+ Wedtxt;
				IDMon.find('.day__people').append(Wedtxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(WedCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
			}
			if(WedCount == 0){IDMon.addClass('day--empty');}
			
		}else if(DateWise[0] == 'Thu'){ // Thursday date of birth	
			if (Age > 0){ var condition = 'success';}			
			if(condition == 'success'){
				ThuCount = ThuCount+1;		
				var Thutxt='',IDMon=$('#thu');	
				Thutxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				Thutxt = " "+ Thutxt;
				IDMon.find('.day__people').append(Thutxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(ThuCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
			}
			if(ThuCount == 0){IDMon.addClass('day--empty');}
	
		}else if(DateWise[0] == 'Fri'){ // Friday date of birth	
			if (Age > 0){ var condition = 'success';}			
			if(condition == 'success'){
				FriCount = FriCount+1;		
				var Fritxt='',IDMon=$('#fri');	
				Fritxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				Fritxt = " "+ Fritxt;
				IDMon.find('.day__people').append(Fritxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(FriCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);	
			}
			if(FriCount == 0){IDMon.addClass('day--empty');}
		
		}else if(DateWise[0] == 'Sat'){ // Saturday date of birth	
			if (Age > 0){ var condition = 'success';}			
			if(condition == 'success'){
				SatCount = SatCount+1;		
				var Sattxt='',IDMon=$('#sat');	
				Sattxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				Sattxt = " "+ Sattxt;
				IDMon.find('.day__people').append(Sattxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(SatCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);	
			}
			if(SatCount == 0){IDMon.addClass('day--empty');}
			
			}else if(DateWise[0] == 'Sun'){ // Sunday date of birth
			if (Age > 0){ var condition = 'success';}			
			if(condition == 'success'){
				SunCount = SunCount+1;		
				var Suntxt='',IDMon=$('#sun');	
				Suntxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				Suntxt = " "+ Suntxt;
				IDMon.find('.day__people').append(Suntxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(SunCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
			}
			if(SunCount == 0){IDMon.addClass('day--empty');}
		}
		
}
	// Div widht and Height assign
	function WidthHeightAssign(b){
		if(b == '1'){ widthSize = 100 + '%'; 	 heightSize = 100 + '%';
		}else if(b == '2'){ widthSize = 100/2 + '%'; heightSize = 100/2 + '%';
		}else if(b == '3'){ widthSize = 100/3 + '%'; heightSize = 100/3 + '%';
		}else { widthSize = 100/3 + '%'; heightSize = 100/3 + '%'; }			
	}
	
	// if(DataNoEmpty !== 'mon'){$('#mon').addClass('day--empty');}	
	// if(DataNoEmpty !== 'tue'){$('#tue').addClass('day--empty');}	
	// if(DataNoEmpty !== 'wed'){$('#wed').addClass('day--empty');}	
	// if(DataNoEmpty !== 'thu'){$('#thu').addClass('day--empty');}	
	// if(DataNoEmpty !== 'fri'){$('#fri').addClass('day--empty');}	
	// if(DataNoEmpty !== 'sat'){$('#sat').addClass('day--empty');}	
	// if(DataNoEmpty !== 'sun'){$('#sun').addClass('day--empty');}	
	
	
};
