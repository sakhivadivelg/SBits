 function myFunction(){  
	//Clear the day__person div
	$('.day__people').find('.day__person').remove();
	var employees=[];
	var sortEmployees=[];
	
	
	var MonCount=0,TueCount=0,WedCount=0,ThuCount=0,FriCount=0,SatCount=0,SunCount=0;
	var CurrentYear=document.getElementById("js-year").value;
	
	// JSON loop
	for ( var i = 0; i < 50; i++) {   
		var x=document.getElementById("json-input").value;
		var y = eval(x);
		
		// Get Year value
		var YearVal = y[i].birthday;
		YearVal = YearVal.split('/');
		var Age = CurrentYear - YearVal[2] ;
		//alert(Age)
		// Get Day on text format
		var DateOfBirth = '"'+y[i].birthday+'"';
		var DateWise = new Date(DateOfBirth);	
		DateWise = DateWise.toDateString().split(' ').slice(',');
		
		// Split the name first letter
		var NameSplit = y[i].name;
		var fullName = NameSplit;
		NameSplit = NameSplit.split(' ').slice(',');
		var FirstLetter  =  NameSplit[0];
		var SecondLetter =  NameSplit[1];
		var SplitName =FirstLetter[0]+''+SecondLetter[0];	
		
		// Day condition checked
		if(DateWise[0] == 'Mon'){  // Monday date of birth
				var Montxt='',IDMon=$('#mon');
				IDMon.removeClass('day--empty');
				if (Age >= 0){
					MonCount = MonCount+1;	
					Montxt = '<div class="day__person" class="day__person" data-year="'+YearVal[2]+'"  data-age="'+Age+'" data-name="'+fullName+'">'+SplitName+'</div>'
				} 
				Montxt = " "+ Montxt;
				IDMon.find('.day__people').append(Montxt);			
				
				// Width and Height Assign
				WidthHeightAssign(MonCount);
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }
				
		}else if(DateWise[0] == 'Tue'){ // Tuesday date of birth
				var Tuetxt='',IDMon=$('#tue');
				if (Age > 0){	
					TueCount = TueCount+1;
					Tuetxt = '<div class="day__person" data-year="'+YearVal[2]+'" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Tuetxt = " "+ Tuetxt;
				IDMon.find('.day__people').append(Tuetxt);
				
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(TueCount);
							
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }
					
		
		}else if(DateWise[0] == 'Wed'){	// Wednesday date of birth	
				var Wedtxt='',IDMon=$('#wed');	
				if (Age >= 0){
					WedCount = WedCount+1;	
					Wedtxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Wedtxt = " "+ Wedtxt;
				IDMon.find('.day__people').append(Wedtxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(WedCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }
			
			
		}else if(DateWise[0] == 'Thu'){ // Thursday date of birth
				var Thutxt='',IDMon=$('#thu');	
				if (Age >= 0){
					ThuCount = ThuCount+1;	
					Thutxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Thutxt = " "+ Thutxt;
				IDMon.find('.day__people').append(Thutxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(ThuCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }
			
	
		}else if(DateWise[0] == 'Fri'){ // Friday date of birth	
				var Fritxt='',IDMon=$('#fri');
				if (Age >= 0){			
					FriCount = FriCount+1;
					Fritxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Fritxt = " "+ Fritxt;
				IDMon.find('.day__people').append(Fritxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(FriCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }				
			
		
		}else if(DateWise[0] == 'Sat'){ // Saturday date of birth
				var Sattxt='',IDMon=$('#sat');
				if (Age >= 0){	
					SatCount = SatCount+1;
					Sattxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Sattxt = " "+ Sattxt;
				IDMon.find('.day__people').append(Sattxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(SatCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }
			
			
			}else if(DateWise[0] == 'Sun'){ // Sunday date of birth						
				var Suntxt='',IDMon=$('#sun');	
				if (Age >= 0){
					SunCount = SunCount+1;	
					Suntxt = '<div class="day__person" data-age="'+Age+'" data-name="'+SplitName+'">'+SplitName+'</div>'
				}
				Suntxt = " "+ Suntxt;
				IDMon.find('.day__people').append(Suntxt);
				IDMon.removeClass('day--empty')
				
				// Width and Height Assign
				WidthHeightAssign(SunCount);	
				
				IDMon.find('.day__person').css('width',widthSize);
				IDMon.find('.day__person').css('height',heightSize);
				var LenVal = IDMon.find('.day__person').length;
				if(LenVal == 0){  IDMon.addClass('day--empty'); }
			
		}
		
}
	// Div widht and Height assign
	function WidthHeightAssign(b){
		if(b == '1'){ widthSize = 100 + '%'; 	 heightSize = 100 + '%';
		}else if(b == '2'){ widthSize = 100/2 + '%'; heightSize = 100/2 + '%';
		}else if(b == '3'){ widthSize = 100/3 + '%'; heightSize = 100/3 + '%';
		}else { widthSize = 100/3 + '%'; heightSize = 100/3 + '%'; }			
	}
	

};
